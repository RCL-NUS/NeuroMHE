"""
This file plots figures showing wrench estimation and trajectory-tracking performances of NeuroMHE
Evaluation data-set is synthetic disturbance data which is state-dependent
==============================================================================================
Wang Bingheng, at Control and Simulation Lab, NUS, Singapore
first version: 24 Dec. 2021
second version: 27 May. 2022
wangbingheng@u.nus.edu
"""
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import matplotlib.ticker

"""--------------Load data----------------"""
# position history during training
Position_training = np.load('Position_train_NeuroMHE.npy')
act_x_0 = Position_training[0][0,:]
act_y_0 = Position_training[0][1,:]
act_z_0 = Position_training[0][2,:]
act_x_1 = Position_training[1][0,:]
act_y_1 = Position_training[1][1,:]
act_z_1 = Position_training[1][2,:]
act_x_2 = Position_training[2][0,:]
act_y_2 = Position_training[2][1,:]
act_z_2 = Position_training[2][2,:]
# position history in evaluation
position_eval_NeuroMHE = np.load('Position_NeuroMHE_evaluation.npy')
position_eval_DMHE     = np.load('Position_DMHE_evaluation.npy')
# reference position 
Ref_p = np.load('Reference_position.npy')
ref_x = Ref_p[0,:]
ref_y = Ref_p[1,:]
ref_z = Ref_p[2,:]
# time
time = np.load('Time_evaluation.npy')
# ground truth force (inertial frame)
Dis_f = np.load('Dis_f_for_test2.npy')
# force estimate history of NeuroMHE in training
Df_neuromhe_train = np.load('Dis_f_NeuroMHE_train.npy')
# full state history in training
Full_state = np.load('FULLSTATE.npy')
# force estimate of NeuroMHE in evaluation
Df_neuromhe = np.load('Dist_f_NeuroMHE_evaluation.npy')
# force estimate of DMHE in evaluation
Dt_dmhe = np.load('Dist_f_DMHE_evaluation.npy')
# time-varying weight matrices in evaluation
weight_para = np.load('Tunable_para_evaluation_NeuroMHE.npy')
# rmse of force estimation error and trajectory-tracking error
Rmse_fx_NeuroMHE = np.load('Rmse_fx_neuroMHE.npy')
Rmse_fy_NeuroMHE = np.load('Rmse_fy_neuroMHE.npy')
Rmse_fz_NeuroMHE = np.load('Rmse_fz_neuroMHE.npy')
Rmse_px_NeuroMHE = np.load('Rmse_px_neuroMHE.npy')
Rmse_py_NeuroMHE = np.load('Rmse_py_neuroMHE.npy')
Rmse_pz_NeuroMHE = np.load('Rmse_pz_neuroMHE.npy')
Rmse_fx_DMHE = np.load('Rmse_fx_DMHE.npy')
Rmse_fy_DMHE = np.load('Rmse_fy_DMHE.npy')
Rmse_fz_DMHE = np.load('Rmse_fz_DMHE.npy')
Rmse_px_DMHE = np.load('Rmse_px_DMHE.npy')
Rmse_py_DMHE = np.load('Rmse_py_DMHE.npy')
Rmse_pz_DMHE = np.load('Rmse_pz_DMHE.npy')
RMSE_fx_NeuroMHE = np.zeros((len(Rmse_fx_NeuroMHE),1))
RMSE_fy_NeuroMHE = np.zeros((len(Rmse_fy_NeuroMHE),1))
RMSE_fz_NeuroMHE = np.zeros((len(Rmse_fz_NeuroMHE),1))
RMSE_px_NeuroMHE = np.zeros((len(Rmse_px_NeuroMHE),1))
RMSE_py_NeuroMHE = np.zeros((len(Rmse_py_NeuroMHE),1))
RMSE_pz_NeuroMHE = np.zeros((len(Rmse_pz_NeuroMHE),1))
RMSE_fx_DMHE = np.zeros((len(Rmse_fx_DMHE),1))
RMSE_fy_DMHE = np.zeros((len(Rmse_fy_DMHE),1))
RMSE_fz_DMHE = np.zeros((len(Rmse_fz_DMHE),1))
RMSE_px_DMHE = np.zeros((len(Rmse_px_DMHE),1))
RMSE_py_DMHE = np.zeros((len(Rmse_py_DMHE),1))
RMSE_pz_DMHE = np.zeros((len(Rmse_pz_DMHE),1))
for i in range(len(Rmse_fx_NeuroMHE)):
    RMSE_fx_NeuroMHE[i,0] = Rmse_fx_NeuroMHE[i]
    RMSE_fy_NeuroMHE[i,0] = Rmse_fy_NeuroMHE[i]
    RMSE_fz_NeuroMHE[i,0] = Rmse_fz_NeuroMHE[i]
    RMSE_px_NeuroMHE[i,0] = Rmse_px_NeuroMHE[i]
    RMSE_py_NeuroMHE[i,0] = Rmse_py_NeuroMHE[i]
    RMSE_pz_NeuroMHE[i,0] = Rmse_pz_NeuroMHE[i]
    RMSE_fx_DMHE[i,0] = Rmse_fx_DMHE[i]
    RMSE_fy_DMHE[i,0] = Rmse_fy_DMHE[i]
    RMSE_fz_DMHE[i,0] = Rmse_fz_DMHE[i]
    RMSE_px_DMHE[i,0] = Rmse_px_DMHE[i]
    RMSE_py_DMHE[i,0] = Rmse_py_DMHE[i]
    RMSE_pz_DMHE[i,0] = Rmse_pz_DMHE[i]
# inverse of noise covariance
Cov_inv_f = np.load('Cov_inv_f_training.npy')
inverse_fx = Cov_inv_f[0,:]
inverse_fy = Cov_inv_f[1,:]
inverse_fz = Cov_inv_f[2,:]

# loss and training episode
loss_neuromhe = np.load('Loss_NeuroMHE.npy')
loss_dmhe     = np.load('Loss_DMHE.npy')
k_iter_neuromhe = np.load('K_iteration_NeuroMHE.npy')
k_iter_dmhe     = np.load('K_iteration_DMHE.npy')
"""------------Plot figures---------------"""
font1 = {'family': 'DejaVu Sans',
         'weight':'normal',
         'size':12}
cm_2_inch = 2.54
# class ScalarFormatterClass(ScalarFormatter):
#     def _set_format(self):
#         self.format = "%1.2f"
class OOMFormatter(matplotlib.ticker.ScalarFormatter):
    def __init__(self,order=0,fformat="%1.1f",offset=True,mathText=True):
        self.oom = order
        self.fformat = fformat
        matplotlib.ticker.ScalarFormatter.__init__(self, useOffset=offset,useMathText=mathText)
    def _set_order_of_magnitude(self):
        self.orderOfMagnitude = self.oom
    def _set_format(self,vmin=None,vmax=None):
        self.format = self.fformat
        if self._useMathText:
            self.format = r'$\mathdefault{%s}$'% self.format 


# 3D trajectory tracking figure
plt.figure(1, figsize=(10/cm_2_inch,7.5/cm_2_inch),dpi=600)
ax = plt.axes(projection="3d")
ax.xaxis._axinfo["grid"].update({"linewidth":0.5})
ax.yaxis._axinfo["grid"].update({"linewidth":0.5})
ax.zaxis._axinfo["grid"].update({"linewidth":0.5})
ax.xaxis._axinfo["grid"].update({"linestyle":'--'})
ax.yaxis._axinfo["grid"].update({"linestyle":'--'})
ax.zaxis._axinfo["grid"].update({"linestyle":'--'})
ax.plot3D(ref_x, ref_y, ref_z, linewidth=1, linestyle='--', label='Reference')
ax.plot3D(act_x_0, act_y_0, act_z_0, linewidth=1, label='untrained')
ax.plot3D(act_x_1, act_y_1, act_z_1, linewidth=0.75, label='1st trained')
ax.plot3D(act_x_2, act_y_2, act_z_2, linewidth=0.5, label='2nd trained')
mpl.rcParams['patch.linewidth']=0.5
ax.legend(loc=(0.11,0.16),fontsize=6)
# plt.quiver(0.04, 0.04, 0, 0, 0, 0.3, color='black',linewidth=0.5)
# plt.quiver(0.04, 0.04, 1.1, 0.2, 0.2, 0, color='black',linewidth=0.5)
ax.tick_params(axis='x',which='major',pad=-2, labelsize=6)
ax.set_xlabel('x [m]', labelpad=-8, fontsize=6)
ax.set_xlim(-0.75,0.75)
ax.set_xticks([-0.5,0,0.5])
ax.tick_params(axis='y',which='major',pad=-2, labelsize=6)
ax.set_ylabel('y [m]', labelpad=-8, fontsize=6)
ax.set_ylim(-1.25,1.25)
ax.set_yticks([-1,0,1])
ax.tick_params(axis='z',which='major',pad=-2, labelsize=6)
ax.set_zlabel('z [m]', labelpad=-8, fontsize=6)
ax.set_zlim(0,1.5)
ax.set_zticks([0,0.75,1.5])
for axis in [ax.w_xaxis, ax.w_yaxis, ax.w_zaxis]:
    axis.line.set_linewidth(0.5)
ax.view_init(22,11)
plt.savefig('./3d_trajectory.png')
plt.show()   

# force and torque estimation by NeuroMHE
# plt.figure(2, figsize=(5/cm_2_inch,5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[0,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_Imh[0,:], linewidth=0.5, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=-2, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Force in x axis [N]',labelpad=-1.5, fontsize=6)
# plt.yticks(np.arange(-5, 2, 2), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# leg = ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-1)
# ax.tick_params(axis='y',which='major',pad=0)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./force_x.png')
# plt.show()

# plt.figure(3, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[1,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_Imh[1,:], linewidth=0.5, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Force in y axis [N]',labelpad=0, fontsize=6)
# plt.yticks(np.arange(-4, 1.1, 1), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='both',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./force_y.png')
# plt.show()

# plt.figure(4, figsize=(5/cm_2_inch,5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[2,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_Imh[2,:], linewidth=0.5, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=-2, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Force in z axis [N]',labelpad=-1.5, fontsize=6)
# plt.yticks(np.arange(-4, 14, 4), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-1)
# ax.tick_params(axis='y',which='major',pad=0)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./force_z.png')
# plt.show()

# plt.figure(5, figsize=(5/cm_2_inch,5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[3,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Dt_Bmh[0,:], linewidth=0.5, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=-2, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Torque in x axis [Nm]',labelpad=-5, fontsize=6)
# plt.yticks(np.arange(-0.005, 0.025, 0.005), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-1)
# ax.tick_params(axis='y',which='major',pad=-1.5)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-2,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./torque_x.png')
# plt.show()

# plt.figure(6, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[4,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Dt_Bmh[1,:], linewidth=0.5, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Torque in y axis [Nm]',labelpad=-2, fontsize=6)
# plt.yticks(np.arange(-0.1, 0.02, 0.02), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-1,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./torque_y.png')
# plt.show()

# plt.figure(7, figsize=(5/cm_2_inch,5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, Dis_t[5,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Dt_Bmh[2,:], linewidth=0.1, label='NeuroMHE')
# plt.xlabel('Time [s]', labelpad=-2, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Torque in z axis [Nm]',labelpad=-5, fontsize=6)
# plt.yticks(np.arange(-0.002, 0.005, 0.002), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-1)
# ax.tick_params(axis='y',which='major',pad=-1.5)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-3,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./torque_z.png')
# plt.show()

# loss
# plt.figure(8, figsize=(3.5/cm_2_inch, 5.5/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(trained, loss, linewidth=1, marker='o', markersize=3)
# plt.xlabel('Training episode', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,3.1,1), fontsize=6)
# plt.ylabel('Mean loss',labelpad=-1, fontsize=6)
# plt.yticks(np.arange(0,81,20),fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(1,"%1.0f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./meanloss.png')
# plt.show()

# inverse of noise covariance
# plt.figure(9, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, inverse_fx, linewidth=0.5, label='noise in x axis')
# plt.plot(time, inverse_fy, linewidth=0.5, label='noise in y axis')
# plt.plot(time, inverse_fz, linewidth=0.5, label='noise in z axis')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Inverse of noise variance',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0,1.1,0.2),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# plt.savefig('./inverse_force.png')
# plt.show()

# plt.figure(10, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, inverse_tx, linewidth=0.1, label='noise in x axis')
# plt.plot(time, inverse_ty, linewidth=0.25, label='noise in y axis')
# plt.plot(time, inverse_tz, linewidth=0.5, label='noise in z axis')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Inverse of noise variance',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0,10001,2000),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(4,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./inverse_torque.png')
# plt.show()

# plt.figure(11, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,24], linewidth=0.5)
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Forgetting factor for measurement',labelpad=0, fontsize=6)
# plt.yticks(fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-6,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./gamma1_fig.png')
# plt.show()

# plt.figure(12, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,43], linewidth=0.5)
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Forgetting factor for process',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0.01,0.017,0.002),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-2,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./gamma2_fig.png')
# plt.show()

# plt.figure(13, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,28], linewidth=0.5, label='4th element')
# plt.plot(time[0:1572], weight_para[0:1572,29], linewidth=0.5, label='5th element')
# plt.plot(time[0:1572], weight_para[0:1572,30], linewidth=0.5, label='6th element')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Elements in measurement weight',labelpad=0, fontsize=6)
# plt.yticks(fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(3,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./R_elements.png')
# plt.show()