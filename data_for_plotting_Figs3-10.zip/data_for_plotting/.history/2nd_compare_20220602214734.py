# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# def print_hi(name):
#     # Use a breakpoint in the code line below to debug your script.
#     print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.
#
#
# # Press the green button in the gutter to run the script.
# if __name__ == '__main__':
#     print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
from cProfile import label
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
cm_2_inch = 2.54
data_first = pd.read_csv("042346vlp.csv")
data_mhe = pd.read_csv("041608vlp.csv")
data_mhe_2 = pd.read_csv("041608pst.csv")
data_pd = pd.read_csv("041851vlp.csv")
data_pid = pd.read_csv("042130vlp.csv")
#data_second = pd.read_csv("042636vlp.csv")
#data_third = pd.read_csv("042911vlp.csv")
dataframe_first = pd.DataFrame(data_first)
dataframe_mhe = pd.DataFrame(data_mhe)
dataframe_pd = pd.DataFrame(data_pd)
dataframe_pid = pd.DataFrame(data_pid)
dataframe_mhe_2 = pd.DataFrame(data_mhe_2)
#dataframe_second = pd.DataFrame(data_second)
#dataframe_third = pd.DataFrame(data_third)
#print(dataframe['current.vx'])
# y_init = pd.Series()
# y_init = pd.DataFrame(np.zeros((10*40)))
# for i in range(10*40-1):
#     y_init.append = 0
#print(y_init)
y_first = -dataframe_first['z']
y_init = y_first.values.tolist()
y_pad = []
for i in range(10*40):
    y_pad.append(0)
y_pad = y_pad + y_init
y_mhe = -dataframe_mhe['z']
y_pd = -dataframe_pd['z']
y_pid = -dataframe_pid['z']
f_mhe = dataframe_mhe_2['current.vx']
#y_second = -dataframe_second['z']
#y_third = -dataframe_third['z']
y_MHE_re =[]
size_first = len(y_pad)
size_mhe = y_mhe.size
size_pd = y_pd.size
size_pid = y_pid.size
#size_second = y_second.size
#size_third = y_third.size
first_time = []
mhe_time = []
pd_time = []
pid_time = []
#second_time = []
#third_time = []
for i in range(size_first):
    first_time.append(i/40)
    #y_MHE_re.append(y_MHE[i])
# for i in range(size_second):
#     second_time.append(i/10)
#     #y_MHE_re.append(y_MHE[i])
# for i in range(size_third):
#     third_time.append(i/10)
#     #y_MHE_re.append(y_MHE[i])
#print(len(x_time))
#print(x_time)
#print(y_MHE)
for i in range(size_mhe):
    mhe_time.append(i/10)

for i in range(size_pd):
    pd_time.append(i/10)

for i in range(size_pid):
    pid_time.append(i/10)

size = f_mhe.size
x_time = []
y_extract = []
for i in range(size):
    x_time.append(i/20)

print(y_pad)
# font1 = {'family':'Times New Roman', 'weight':'normal','size':12}
# plt.figure(1, figsize=(8/cm_2_inch,8*0.75/cm_2_inch), dpi=600)
# ax = plt.gca()
# # plt.title("Neural MHE vs no-MHE vs PID: Hover under downwash",font1)
# plt.plot(first_time, y_pad, 'tab:purple', linestyle='--', label='2nd quadrotor')
# plt.plot(mhe_time, y_mhe,'tab:blue',label='Ego quadrotor with NeuroMHE ')
# plt.plot(pd_time, y_pd,'tab:orange', linestyle='-.', label='Ego quadrotor without NeuroMHE')
# # plt.plot(pid_time, y_pid,'tab:green')
# #plt.plot(second_time,y_second,'tab:orange')
# #plt.plot(third_time,y_third,'tab:green')
# plt.xlabel('Time [s]',labelpad=0,fontsize=6)
# plt.xticks(np.arange(0,45.1,5), fontsize=6)
# plt.ylabel('Height [m]',labelpad=0,fontsize=6)
# plt.yticks(np.arange(0, 2.6, 0.5),fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# plt.xlim([0.0, 45.0])
# plt.ylim([-0.1, 2.5])
# ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0)
# ax.tick_params(axis='y',which='major',pad=0)
# plt.savefig('./MHE_vs_nomhe_hover_under_downwash.png')
# plt.show()

plt.figure(2, figsize=(8/cm_2_inch,8*0.75/cm_2_inch), dpi=600)
ax = plt.gca()
plt.plot(x_time, f_mhe,linewidth=1)
plt.xlabel('Time [s]',labelpad=0,fontsize=6)
plt.xticks(np.arange(0,45.1,5), fontsize=6)
plt.ylabel('Disturbance estimate in z axis [N]',labelpad=0,fontsize=6)
plt.yticks(np.arange(-10, 10.1, 2.5),fontsize=6)
plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
plt.xlim([0.0, 45.0])
plt.ylim([-10, 10])
ax.tick_params(axis='x',which='major',pad=0)
ax.tick_params(axis='y',which='major',pad=0)
for axis in ['top', 'bottom', 'left', 'right']:
    ax.spines[axis].set_linewidth(0.5)
plt.savefig('./MHE_downwash.png',dpi=600)
plt.show()