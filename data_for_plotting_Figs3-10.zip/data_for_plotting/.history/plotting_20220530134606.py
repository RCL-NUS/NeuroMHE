"""
This file plots figures showing wrench estimation and trajectory-tracking performances of NeuroMHE
Evaluation data-set is synthetic disturbance data which is state-dependent
==============================================================================================
Wang Bingheng, at Control and Simulation Lab, NUS, Singapore
first version: 24 Dec. 2021
second version: 27 May. 2022
wangbingheng@u.nus.edu
"""
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import matplotlib.ticker
from UavEnv import *

uav_para = np.array([0.752, 0.00252, 0.00214, 0.00436])
wing_len = 0.4
# Sampling time-step for MHE
dt_sample = 1e-2
uavmodel = quadrotor(uav_para,dt_sample)
"""--------------Load data----------------"""
# position history during training
Position_training = np.load('Position_train_NeuroMHE.npy')
act_x_0 = Position_training[0][0,:]
act_y_0 = Position_training[0][1,:]
act_z_0 = Position_training[0][2,:]
act_x_1 = Position_training[1][0,:]
act_y_1 = Position_training[1][1,:]
act_z_1 = Position_training[1][2,:]
act_x_2 = Position_training[2][0,:]
act_y_2 = Position_training[2][1,:]
act_z_2 = Position_training[2][2,:]
# position history in evaluation
position_eval_NeuroMHE = np.load('Position_NeuroMHE_evaluation.npy')
position_eval_DMHE     = np.load('Position_DMHE_evaluation.npy')
# reference position 
Ref_p = np.load('Reference_position.npy')
ref_x = Ref_p[0,:]
ref_y = Ref_p[1,:]
ref_z = Ref_p[2,:]
# time
time = np.load('Time_evaluation.npy')
# ground truth force in training
Dis_f_train = np.load('Dis_f_for_training.npy')
# ground truth force (inertial frame) in evaluation
Dis_f = np.load('Dis_f_for_test2.npy')
# force estimate history of NeuroMHE in training
Df_neuromhe_train = np.load('Dis_f_NeuroMHE_train.npy')
dfx_train_0  = Df_neuromhe_train[0][0,:]
dfy_train_0  = Df_neuromhe_train[0][1,:]
dfz_train_0  = Df_neuromhe_train[0][2,:]
dfx_train_1  = Df_neuromhe_train[1][0,:]
dfy_train_1  = Df_neuromhe_train[1][1,:]
dfz_train_1  = Df_neuromhe_train[1][2,:]
dfx_train_2  = Df_neuromhe_train[2][0,:]
dfy_train_2  = Df_neuromhe_train[2][1,:]
dfz_train_2  = Df_neuromhe_train[2][2,:]
# full state history in training
Full_state = np.load('FULLSTATE.npy')
# force estimate of NeuroMHE in evaluation
Df_neuromhe = np.load('Dist_f_NeuroMHE_evaluation.npy')
# force estimate of DMHE in evaluation
Df_dmhe = np.load('Dist_f_DMHE_evaluation.npy')
# force estimate of manually tuned MHE in evaluation
Df_manualmhe = np.load('Dist_f_manual_MHE_evaluation.npy')
# tracking error
Error_neuromhe = np.load('Error_NeuroMHE_evaluation.npy')
Error_dmhe     = np.load('Error_DMHE_evaluation.npy')
# time-varying weight matrices in evaluation
weight_para = np.load('Tunable_para_evaluation_NeuroMHE.npy')
# rmse of force estimation error and trajectory-tracking error
Rmse_fx_NeuroMHE = np.load('Rmse_fx_neuroMHE.npy')
Rmse_fy_NeuroMHE = np.load('Rmse_fy_neuroMHE.npy')
Rmse_fz_NeuroMHE = np.load('Rmse_fz_neuroMHE.npy')
Rmse_px_NeuroMHE = np.load('Rmse_px_neuroMHE.npy')
Rmse_py_NeuroMHE = np.load('Rmse_py_neuroMHE.npy')
Rmse_pz_NeuroMHE = np.load('Rmse_pz_neuroMHE.npy')
Rmse_fx_DMHE = np.load('Rmse_fx_DMHE.npy')
Rmse_fy_DMHE = np.load('Rmse_fy_DMHE.npy')
Rmse_fz_DMHE = np.load('Rmse_fz_DMHE.npy')
Rmse_px_DMHE = np.load('Rmse_px_DMHE.npy')
Rmse_py_DMHE = np.load('Rmse_py_DMHE.npy')
Rmse_pz_DMHE = np.load('Rmse_pz_DMHE.npy')
RMSE_fx_NeuroMHE = np.zeros((len(Rmse_fx_NeuroMHE),1))
RMSE_fy_NeuroMHE = np.zeros((len(Rmse_fy_NeuroMHE),1))
RMSE_fz_NeuroMHE = np.zeros((len(Rmse_fz_NeuroMHE),1))
RMSE_px_NeuroMHE = np.zeros((len(Rmse_px_NeuroMHE),1))
RMSE_py_NeuroMHE = np.zeros((len(Rmse_py_NeuroMHE),1))
RMSE_pz_NeuroMHE = np.zeros((len(Rmse_pz_NeuroMHE),1))
RMSE_fx_DMHE = np.zeros((len(Rmse_fx_DMHE),1))
RMSE_fy_DMHE = np.zeros((len(Rmse_fy_DMHE),1))
RMSE_fz_DMHE = np.zeros((len(Rmse_fz_DMHE),1))
RMSE_px_DMHE = np.zeros((len(Rmse_px_DMHE),1))
RMSE_py_DMHE = np.zeros((len(Rmse_py_DMHE),1))
RMSE_pz_DMHE = np.zeros((len(Rmse_pz_DMHE),1))
for i in range(len(Rmse_fx_NeuroMHE)):
    RMSE_fx_NeuroMHE[i,0] = Rmse_fx_NeuroMHE[i]
    RMSE_fy_NeuroMHE[i,0] = Rmse_fy_NeuroMHE[i]
    RMSE_fz_NeuroMHE[i,0] = Rmse_fz_NeuroMHE[i]
    RMSE_px_NeuroMHE[i,0] = Rmse_px_NeuroMHE[i]
    RMSE_py_NeuroMHE[i,0] = Rmse_py_NeuroMHE[i]
    RMSE_pz_NeuroMHE[i,0] = Rmse_pz_NeuroMHE[i]
    RMSE_fx_DMHE[i,0] = Rmse_fx_DMHE[i]
    RMSE_fy_DMHE[i,0] = Rmse_fy_DMHE[i]
    RMSE_fz_DMHE[i,0] = Rmse_fz_DMHE[i]
    RMSE_px_DMHE[i,0] = Rmse_px_DMHE[i]
    RMSE_py_DMHE[i,0] = Rmse_py_DMHE[i]
    RMSE_pz_DMHE[i,0] = Rmse_pz_DMHE[i]
# inverse of noise covariance
Cov_inv_f = np.load('Cov_inv_f_training.npy')
inverse_fx = Cov_inv_f[0,:]
inverse_fy = Cov_inv_f[1,:]
inverse_fz = Cov_inv_f[2,:]

# loss and training episode
loss_neuromhe = np.load('Loss_NeuroMHE.npy')
loss_dmhe     = np.load('Loss_DMHE.npy')
k_iter_neuromhe = np.load('K_iteration_NeuroMHE.npy')
k_iter_dmhe     = np.load('K_iteration_DMHE.npy')
"""------------Plot figures---------------"""
font1 = {'family': 'DejaVu Sans',
         'weight':'normal',
         'size':12}
cm_2_inch = 2.54
# class ScalarFormatterClass(ScalarFormatter):
#     def _set_format(self):
#         self.format = "%1.2f"
class OOMFormatter(matplotlib.ticker.ScalarFormatter):
    def __init__(self,order=0,fformat="%1.1f",offset=True,mathText=True):
        self.oom = order
        self.fformat = fformat
        matplotlib.ticker.ScalarFormatter.__init__(self, useOffset=offset,useMathText=mathText)
    def _set_order_of_magnitude(self):
        self.orderOfMagnitude = self.oom
    def _set_format(self,vmin=None,vmax=None):
        self.format = self.fformat
        if self._useMathText:
            self.format = r'$\mathdefault{%s}$'% self.format 


# 3D trajectory tracking figure
# plt.figure(1, figsize=(10/cm_2_inch,7.5/cm_2_inch),dpi=600)
# ax = plt.axes(projection="3d")
# ax.xaxis._axinfo["grid"].update({"linewidth":0.5})
# ax.yaxis._axinfo["grid"].update({"linewidth":0.5})
# ax.zaxis._axinfo["grid"].update({"linewidth":0.5})
# ax.xaxis._axinfo["grid"].update({"linestyle":'--'})
# ax.yaxis._axinfo["grid"].update({"linestyle":'--'})
# ax.zaxis._axinfo["grid"].update({"linestyle":'--'})
# state_ut = Full_state[:,0*1300:1*1300]
# ax.plot3D(ref_x, ref_y, ref_z, linewidth=1, linestyle='--', label='Reference')
# ax.plot3D(state_ut[0,:], state_ut[1,:], state_ut[2,:], linewidth=1, label='untrained')
# ax.plot3D(act_x_1, act_y_1, act_z_1, linewidth=0.75, label='1st trained')
# ax.plot3D(act_x_2, act_y_2, act_z_2, linewidth=0.5, label='2nd trained')
# mpl.rcParams['patch.linewidth']=0.5
# ax.legend(loc=(0.11,0.16),fontsize=6)
# plt.quiver(0, -1, 1.7, 0, 0, -0.2, color='black',linewidth=0.5)
# plt.quiver(0, -0.5, 1.7, 0, 0, -0.2, color='black',linewidth=0.5)
# plt.quiver(0, 0, 1.7, 0, 0, -0.2, color='black',linewidth=0.5)
# plt.quiver(0, 0.5, 1.7, 0, 0, -0.2, color='black',linewidth=0.5)
# plt.quiver(0, 1, 1.7, 0, 0, -0.2, color='black',linewidth=0.5)
# ax.text(-0.2,-1,1.7,"Major disturbance direction",fontsize=6)
# position = uavmodel.get_quadrotor_position(wing_len,state_ut)
# for i in range(3):
#     c_x, c_y, c_z = position[0:3,i*500]
#     r1_x, r1_y, r1_z = position[3:6,i*500]
#     r2_x, r2_y, r2_z = position[6:9,i*500]
#     r3_x, r3_y, r3_z = position[9:12,i*500]
#     r4_x, r4_y, r4_z = position[12:15,i*500]
#     ax.plot([c_x, r1_x], [c_y, r1_y], [c_z, r1_z], linewidth=0.5, color='black', marker='o', markersize=1.5)
#     ax.plot([c_x, r2_x], [c_y, r2_y], [c_z, r2_z], linewidth=0.5, color='black', marker='o', markersize=1.5)
#     ax.plot([c_x, r3_x], [c_y, r3_y], [c_z, r3_z], linewidth=0.5, color='black', marker='o', markersize=1.5)
#     ax.plot([c_x, r4_x], [c_y, r4_y], [c_z, r4_z], linewidth=0.5, color='black', marker='o', markersize=1.5)

# ax.tick_params(axis='x',which='major',pad=-2, labelsize=6)
# ax.set_xlabel('x [m]', labelpad=-8, fontsize=6)
# ax.set_xlim(-0.75,0.75)
# ax.set_xticks([-0.5,0,0.5])
# ax.tick_params(axis='y',which='major',pad=-2, labelsize=6)
# ax.set_ylabel('y [m]', labelpad=-8, fontsize=6)
# ax.set_ylim(-1.25,1.25)
# ax.set_yticks([-1,0,1])
# ax.tick_params(axis='z',which='major',pad=-2, labelsize=6)
# ax.set_zlabel('z [m]', labelpad=-8, fontsize=6)
# ax.set_zlim(0,1.7)
# ax.set_zticks([0,0.75,1.5])
# for axis in [ax.w_xaxis, ax.w_yaxis, ax.w_zaxis]:
#     axis.line.set_linewidth(0.5)
# ax.view_init(17,15)
# plt.savefig('./3d_trajectory.png')
# plt.show()   

# force estimate in training
# plt.figure(2, figsize=(8/cm_2_inch,4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(time, Dis_f_train[2,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, dfz_train_0, linewidth=0.5, label='untrained')
# plt.plot(time, dfz_train_1, linewidth=0.5, label='1st trained')
# plt.plot(time, dfz_train_2, linewidth=0.5, label='2nd trained')
# plt.xlabel('Time [s]', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,16,4),fontsize=6)
# plt.ylabel('Disturbance force [N]',labelpad=-0.5, fontsize=6)
# plt.yticks(np.arange(-25, 10, 10), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./training_force_z.png')
# plt.show()

# comparison of mean loss in training
# plt.figure(3, figsize=(8/cm_2_inch, 4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(k_iter_neuromhe, loss_neuromhe, linewidth=1, marker='o', markersize=3,label='NeuroMHE')
# plt.plot(k_iter_dmhe, loss_dmhe, linewidth=1, marker='o', markersize=3,label='DMHE')
# plt.xlabel('Training epoch', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,5.1,1), fontsize=6)
# plt.ylabel('Mean loss',labelpad=-1, fontsize=6)
# plt.yticks(np.arange(0,50,10),fontsize=6)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# ax.legend(fontsize=6)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# # ax.yaxis.set_major_formatter(OOMFormatter(1,"%1.0f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./training_meanloss.png')
# plt.show()

# comparison of force estimate in evaluation
# plt.figure(4, figsize=(8/cm_2_inch,4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(time, Dis_f[0,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_neuromhe[0,:], linewidth=0.5,color='r', label='NeuroMHE')
# plt.plot(time, Df_manualmhe[0,:], linewidth=0.1, color='c',label='ManualMHE')
# plt.plot(time, Df_dmhe[0,:], linewidth=0.5, label='DMHE')
# plt.xlabel('Time [s]', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,16,4),fontsize=6)
# plt.ylabel('Disturbance force [N]',labelpad=-0.5, fontsize=6)
# plt.yticks(np.arange(-1.5, 1.1,1), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./evaluation_force_x.png')
# plt.show()

# plt.figure(4, figsize=(8/cm_2_inch,4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(time, Dis_f[1,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_neuromhe[1,:], linewidth=0.5,color='r', label='NeuroMHE')
# plt.plot(time, Df_manualmhe[1,:], linewidth=0.1, color='c',label='ManualMHE')
# plt.plot(time, Df_dmhe[1,:], linewidth=0.5, label='DMHE')
# plt.xlabel('Time [s]', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,16,4),fontsize=6)
# plt.ylabel('Disturbance force [N]',labelpad=-0.5, fontsize=6)
# plt.yticks(np.arange(-2.5, 1.1,1), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./evaluation_force_y.png')
# plt.show()

# plt.figure(5, figsize=(8/cm_2_inch,4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(time, Dis_f[2,:], linewidth=1, linestyle='--', label='Ground truth')
# plt.plot(time, Df_neuromhe[2,:], linewidth=0.5,color='r', label='NeuroMHE')
# plt.plot(time, Df_manualmhe[2,:], linewidth=0.1, color='c',label='ManualMHE')
# plt.plot(time, Df_dmhe[2,:], linewidth=0.5, label='DMHE')
# plt.xlabel('Time [s]', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,16,4),fontsize=6)
# plt.ylabel('Disturbance force [N]',labelpad=-0.5, fontsize=6)
# plt.yticks(np.arange(-20, 5,10), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./evaluation_force_z.png')
# plt.show()

# comparison of tracking error in evaluation
# plt.figure(6, figsize=(8/cm_2_inch,4.5/cm_2_inch), dpi=600)
# ax = plt.gca()
# plt.plot(time, Error_neuromhe[2,:], linewidth=0.5,color='r', label='NeuroMHE')
# plt.plot(time, Error_dmhe[2,:], linewidth=0.5, label='DMHE')
# plt.xlabel('Time [s]', labelpad=-1, fontsize=6)
# plt.xticks(np.arange(0,16,4),fontsize=6)
# plt.ylabel('Tracking error [m]',labelpad=-0.5, fontsize=6)
# plt.yticks(np.arange(-0.06, 0.06,0.03), fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# ax.legend(fontsize=6)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.tick_params(axis='x',which='major',pad=-0.25)
# ax.tick_params(axis='y',which='major',pad=-0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)

# plt.savefig('./evaluation_error_z.png')
# plt.show()

plt.figure(7, figsize=(8/cm_2_inch,8*0.75/cm_2_inch), dpi=600)
ax = plt.gca()
plt.plot(ref_y,ref_x, linewidth=1, linestyle='--',label='Reference')
plt.plot(position_eval_NeuroMHE[1,:], position_eval_NeuroMHE[0,:], color='r',linewidth=0.5, label='NeuroMHE')
plt.plot(position_eval_DMHE[1,:], position_eval_DMHE[0,:], linewidth=0.5, label='DMHE')
plt.xlabel('y [m]', labelpad=-1, fontsize=6)
plt.xticks(np.arange(-1, 1.1,0.5),fontsize=6)
plt.ylabel('x [m]',labelpad=-0.5, fontsize=6)
plt.yticks(np.arange(-0.5,0.6,0.5), fontsize=6)
mpl.rcParams['patch.linewidth']=0.5
ax.legend(fontsize=6)
plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
plt.quiver(0, -0.1, 0.2, -0.2, color='black',linewidth=0.5)
ax.tick_params(axis='x',which='major',pad=-0.25)
ax.tick_params(axis='y',which='major',pad=-0.25)
for axis in ['top', 'bottom', 'left', 'right']:
    ax.spines[axis].set_linewidth(0.5)

plt.savefig('./evaluation_plannar.png')
plt.show()

# inverse of noise covariance
# plt.figure(9, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, inverse_fx, linewidth=0.5, label='noise in x axis')
# plt.plot(time, inverse_fy, linewidth=0.5, label='noise in y axis')
# plt.plot(time, inverse_fz, linewidth=0.5, label='noise in z axis')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Inverse of noise variance',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0,1.1,0.2),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# plt.savefig('./inverse_force.png')
# plt.show()

# plt.figure(10, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time, inverse_tx, linewidth=0.1, label='noise in x axis')
# plt.plot(time, inverse_ty, linewidth=0.25, label='noise in y axis')
# plt.plot(time, inverse_tz, linewidth=0.5, label='noise in z axis')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Inverse of noise variance',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0,10001,2000),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(4,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./inverse_torque.png')
# plt.show()

# plt.figure(11, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,24], linewidth=0.5)
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Forgetting factor for measurement',labelpad=0, fontsize=6)
# plt.yticks(fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-6,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./gamma1_fig.png')
# plt.show()

# plt.figure(12, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,43], linewidth=0.5)
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Forgetting factor for process',labelpad=0, fontsize=6)
# plt.yticks(np.arange(0.01,0.017,0.002),fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# # leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(-2,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./gamma2_fig.png')
# plt.show()

# plt.figure(13, figsize=(6.5/cm_2_inch,6.5*0.75/cm_2_inch), dpi=300)
# ax = plt.gca()
# plt.plot(time[0:1572], weight_para[0:1572,28], linewidth=0.5, label='4th element')
# plt.plot(time[0:1572], weight_para[0:1572,29], linewidth=0.5, label='5th element')
# plt.plot(time[0:1572], weight_para[0:1572,30], linewidth=0.5, label='6th element')
# plt.xlabel('Time [s]', labelpad=0, fontsize=6)
# plt.xticks(np.arange(0,16.5,4),fontsize=6)
# plt.ylabel('Elements in measurement weight',labelpad=0, fontsize=6)
# plt.yticks(fontsize=6)
# mpl.rcParams['patch.linewidth']=0.5
# leg = ax.legend(fontsize=6)
# ax.tick_params(axis='x',which='major',pad=0.25)
# ax.tick_params(axis='y',which='major',pad=0.25)
# for axis in ['top', 'bottom', 'left', 'right']:
#     ax.spines[axis].set_linewidth(0.5)
# plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
# ax.yaxis.set_major_formatter(OOMFormatter(3,"%1.1f"))
# ax.yaxis.get_offset_text().set_fontsize(6)
# plt.savefig('./R_elements.png')
# plt.show()