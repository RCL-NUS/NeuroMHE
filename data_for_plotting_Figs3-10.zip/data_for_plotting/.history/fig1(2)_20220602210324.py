# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# def print_hi(name):
#     # Use a breakpoint in the code line below to debug your script.
#     print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.
#
#
# # Press the green button in the gutter to run the script.
# if __name__ == '__main__':
#     print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
cm_2_inch = 2.54
data = pd.read_csv("044224pst.csv")
# data = pd.read_csv("081412vlp.csv")
dataframe = pd.DataFrame(data)
#print(dataframe['current.vx'])
y_MHE = dataframe['current.vx']
size = y_MHE.size
x_time = []
y_extract = []
for i in range(size):
    x_time.append(i/20)
for i in range(int(3.5/0.05),int(27.05/0.05)):
    y_extract.append(y_MHE[i])
print(len(x_time))
print(x_time)
print(y_MHE)
print("hahaha")
print(y_extract)
avg = sum(y_extract) / len(y_extract)
var = sum((x-avg)**2 for x in y_extract) / len(y_extract)
print(avg)
print(var)
font1 = {'family':'Times New Roman', 'weight':'normal','size':12}
plt.figure(1, figsize=(8/cm_2_inch,8*0.75/cm_2_inch), dpi=600)
ax = plt.gca()
# plt.title("Neural MHE: Takeoff with payload",font1)
plt.plot(x_time, y_MHE, linewidth=1)
# plt.fill_between(x_time[20:805], y_MHE[20:805]-math.sqrt(var), y_MHE[20:805]+math.sqrt(var), color='b', alpha=0.2)
plt.xlabel('Time [s]',fontsize=6)
plt.ylabel('Disturbance estimate in z axis [N]',fontsize=6)
plt.xlim([0.0, 40.0])
plt.grid(b=True,axis='both',linestyle='--')
plt.grid(b=True,axis='both',linestyle='--', linewidth=0.5)
ax.tick_params(axis='x',which='major',pad=-1)
ax.tick_params(axis='y',which='major',pad=0)
for axis in ['top', 'bottom', 'left', 'right']:
    ax.spines[axis].set_linewidth(0.5)
plt.savefig('./MHE_takeoff_with_payload.png',dpi=600)
plt.show()
