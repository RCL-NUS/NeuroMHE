import numpy as np

A = np.array([[1,2,3],
              [3,4,5],
              [4,5,6]])
B = A[0:3, 1]
print('B=',B.shape)